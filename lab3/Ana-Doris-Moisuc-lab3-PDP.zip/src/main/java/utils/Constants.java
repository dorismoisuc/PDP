package utils;

public class Constants {
    public static final int NUMBER_OF_THREADS = 4;
    public static final int MATRIX_DIMENSION = 1000;
}
